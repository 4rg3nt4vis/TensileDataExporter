from parser import extractResults
from parser import combineDataframes
import tkinter as tk
from tkinter import filedialog, messagebox
import os
import sys
import subprocess
from version import VERSION
from updater import checkForUpdates, downloadUpdate

class App:
    def __init__(self, root):
        hasUpdate, newestVersion = checkForUpdates(VERSION)
        
        if hasUpdate:
            if messagebox.askyesno(
                    "Update available",
                    f"A newer version ({newestVersion}) is available. Update now?"                    
                    ):
                downloadUpdate()
                subprocess.Popen([sys.executable, "applyUpdate.py"])
                sys.exit(0)
        
        self.root = root
        self.root.title(f"Tensile Test Exporter ({VERSION})")
        self.root.geometry("800x500")
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        self.left_frame = tk.Frame(root, width=250, padx=10, pady=10)
        self.left_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        self.right_frame = tk.Frame(root, padx=10, pady=10)
        self.right_frame.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH)
        
        self.import_button = tk.Button(
            self.left_frame,
            text="Import PDF File(s)",
            relief=tk.RAISED,
            command=self.import_files
            )
        self.import_button.pack(fill=tk.X, pady=(0, 10))
        
        self.import_list_frame = tk.Frame(self.left_frame)
        self.import_list_frame.pack(fill=tk.BOTH, expand=True)
        
        self.copy_button = tk.Button(
            self.right_frame,
            text="Copy",
            relief=tk.RAISED,
            command=self.copy
            )
        self.copy_button.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH)
        
        self.file_entries = []
        self.imports = []
        
    def on_close(self):
        self.root.quit()
        self.root.destroy()
        sys.exit(0)
        
    def import_files(self):
        filepaths = filedialog.askopenfilenames(
            title="Select PDF file(s)",
            filetypes=[("PDF File(s)", "*.pdf")]
            )
        
        for path in filepaths:
            imported = ImportedFile(path)
            self.imports.append(imported)
            self.add_file_entry(imported)
            
    def add_file_entry(self, new_entry):
        entry = tk.Entry(self.import_list_frame)
        entry.insert(0, new_entry.name)
        entry.pack(fill=tk.X, pady=2)
        
        entry.bind(
            "<KeyRelease>",
            lambda event, obj=new_entry, ent=entry: self.update_name(obj, ent)
            )
        
        self.file_entries.append(entry)
        
    def update_name(self, imported_file, entry_widget):
        imported_file.name = entry_widget.get()
        
    def copy(self):
        results = []
        for imp in self.imports:
            results.append(extractResults(imp.name, imp.path))
        combineDataframes(results).to_clipboard(index=False)
        
class ImportedFile:
    def __init__(self, path):
        self.path = path
        self.name = os.path.splitext(os.path.basename(path))[0]

    
if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()