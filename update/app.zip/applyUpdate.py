import shutil
import os
import sys
import time

time.sleep(1)

source = "update_tmp"
target = os.path.dirname(sys.argv[0])

for item in os.listdir(source):
    s = os.path.join(source, item)
    t = os.path.join(target, item)
    
    if os.path.isdir(s):
        shutil.copytree(s, t, dirs_exist_ok=True)
    else:
        shutil.copy2(s, t)
        
shutil.rmtree(source)