import tabula
import pandas as pd

def extractResults(formulation, pdfPath):
    tables = tabula.read_pdf(pdfPath, pages="all")
    
    for df in tables:
        if "Unnamed: 0" in df.columns:
            df.rename(columns={"Unnamed: 0": "Name"}, inplace=True)
    
    dimension_df = tables[0]
    strength_df = tables[1]
    elongation_df = tables[2]
    
    dimension_df = dimension_df[
        dimension_df["Name"].str.contains("_", na=False)
        ]
    
    strength_df = strength_df[
        strength_df["Name"].str.contains("_", na=False)
        ]
    
    elongation_df = elongation_df[
        elongation_df["Name"].str.contains("_", na=False)
        ]
    
    dimension_df = dimension_df.rename(columns={
        "Thickness": "Thickness (mm)",
        "Width": "Width (mm)",
        "Gauge_Length": "Gauge Length (mm)"
        })
    
    strength_df = strength_df.rename(columns={
        "Ultimate Tensile": "Ultimate Tensile Strength (MPa)",
        "Tensile Strength at": "Tensile Strength at Yield (MPa)",
        "Tensile Strength at.1": "Tensile Strength at Break (MPa)",
        "Unnamed: 1": "Elastic Modulus (MPa)"
        })
    
    elongation_df = elongation_df.rename(columns={
        "Elongation at Break": "Elongation at Break (%)",
        "Elongation at Yield": "Elongation at Yield (%)"
        })
    
    dimension_df = dimension_df[[
        "Name",
        "Thickness (mm)",
        "Width (mm)",
        "Gauge Length (mm)"
        ]]
    
    strength_df = strength_df[[
        "Name",
        "Ultimate Tensile Strength (MPa)",
        "Tensile Strength at Yield (MPa)",
        "Tensile Strength at Break (MPa)",
        "Elastic Modulus (MPa)"
        ]]
    
    elongation_df = elongation_df[[
        "Name",
        "Elongation at Break (%)",
        "Elongation at Yield (%)"
        ]]
    
    final_df = dimension_df.merge(
        strength_df,
        on="Name",
        how="left"
        )
    
    final_df = final_df.merge(
        elongation_df,
        on="Name",
        how="left"
        )
    
    final_df["Formulation"] = formulation
    
    final_df = final_df[[
            "Formulation",
            "Thickness (mm)",
            "Width (mm)",
            "Gauge Length (mm)",
            "Ultimate Tensile Strength (MPa)",
            "Tensile Strength at Yield (MPa)",
            "Tensile Strength at Break (MPa)",
            "Elastic Modulus (MPa)",
            "Elongation at Break (%)",
            "Elongation at Yield (%)"
        ]]

    
    return final_df

def combineDataframes(dataFrames):
    return pd.concat(dataFrames, ignore_index=True)
        
    