import requests
from packaging.version import Version
import zipfile
import io
import os

VERSION_URL = "https://github.com/4rg3nt4vis/TensileDataExporter/blob/main/update/version.txt"
ZIP_URL = "https://github.com/4rg3nt4vis/TensileDataExporter/blob/main/update/app.zip"

def checkForUpdates(currentVersion):
    response = requests.get(VERSION_URL, timeout=5)
    response.raise_for_status()
    
    latestVersion = response.text.strip()
    
    return Version(latestVersion) > Version(currentVersion), latestVersion

def downloadUpdate():
    response = requests.get(ZIP_URL)
    response.raise_for_status()
    
    updateDir = "update_tmp"
    os.makedirs(updateDir, exist_ok=True)
    
    with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
        zip_ref.extractall(updateDir)
        
    return updateDir
